from flask import Flask, render_template, request, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
import pandas as pd
import io
import json
from apscheduler.schedulers.background import BackgroundScheduler

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///feedback.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# ---------------------------
# Modelo de dados
# ---------------------------
class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    grau = db.Column(db.String(20), nullable=False)  # 'Muito Satisfeito', 'Satisfeito', 'Insatisfeito'
    data = db.Column(db.Date, nullable=False)
    hora = db.Column(db.Time, nullable=False)
    dia_semana = db.Column(db.String(10), nullable=False)

with app.app_context():
    db.create_all()

# ---------------------------
# Página principal
# ---------------------------
@app.route('/')
def index():
    return render_template('index.html')

# ---------------------------
# Receber feedback
# ---------------------------
@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    grau = request.json.get('grau')
    now = datetime.now()
    feedback = Feedback(
        grau=grau,
        data=now.date(),
        hora=now.time(),
        dia_semana=now.strftime('%A')
    )
    db.session.add(feedback)
    db.session.commit()
    return jsonify({'message': 'Obrigado pelo seu feedback!'}), 200

# ---------------------------
# Área administrativa
# ---------------------------
ADMIN_PASSWORD = 'admin123'

@app.route('/Admin_2026')
def admin_page():
    pwd = request.args.get('password', '')
    if pwd != ADMIN_PASSWORD:
        return "Acesso negado", 403

    dia_filter = request.args.get('dia', 'todos')
    registros_query = Feedback.query.order_by(Feedback.data.desc(), Feedback.hora.desc())

    if dia_filter == 'hoje':
        registros_query = registros_query.filter_by(data=date.today())
    registros = registros_query.all()

    # Estatísticas
    total = len(registros)
    contagem = {
        'Muito Satisfeito': len([r for r in registros if r.grau == 'Muito Satisfeito']),
        'Satisfeito': len([r for r in registros if r.grau == 'Satisfeito']),
        'Insatisfeito': len([r for r in registros if r.grau == 'Insatisfeito'])
    }
    percent = {k: round(v/total*100,2) if total>0 else 0 for k,v in contagem.items()}

    # Preparar JSON para Chart.js
    counts_json = json.dumps([contagem['Muito Satisfeito'], contagem['Satisfeito'], contagem['Insatisfeito']])
    percents_json = json.dumps([percent['Muito Satisfeito'], percent['Satisfeito'], percent['Insatisfeito']])

    return render_template(
        'admin.html',
        registros=registros,
        contagem=contagem,
        percent=percent,
        dia_filter=dia_filter,
        counts_json=counts_json,
        percents_json=percents_json
    )

# ---------
