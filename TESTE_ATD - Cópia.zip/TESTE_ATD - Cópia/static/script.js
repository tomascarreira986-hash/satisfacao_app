const buttons = document.querySelectorAll('.feedback-btn');
const msg = document.getElementById('msg');
let timeoutActive = false;

buttons.forEach(btn => {
    btn.addEventListener('click', () => {
        if(timeoutActive) return;
        const grau = btn.dataset.grau;
        fetch('/submit_feedback', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({grau})
        })
        .then(res => res.json())
        .then(data => {
            msg.textContent = data.message;
            timeoutActive = true;
            setTimeout(() => {
                msg.textContent = '';
                timeoutActive = false;
            }, 3000);
        });
    });
});
